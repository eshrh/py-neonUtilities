import glob
from . import neon
import os
import shutil
import zipfile
import re
from itertools import chain

class NeonObservational(neon.Neon):
    def __init__(self, dpID=None, site=None, dates=None, package="basic", token=None):
        neon.Neon.__init__(self, dpID, site, dates, package, token)
        self.stackedFiles = {}

    def stackByTable(self, root=None, clean=True):
        """
        Method to stack zip files by table

        stackByTable can be used as a class method after downloading files, or you can provide a single argument root
        which is the path to the directory containing zip files. If used as a class method,
        it will create a directory named the dpID of your file. After stacking, the csv files containing
        data will be placed in <dpID>/stackedFiles. The csv name will follow the pattern DESC_stacked.csv.
        You can pass clean=False to not delete expanded files after stacking.
        """

        if not root:
            root = os.path.join(os.getcwd(), self.rootname)
        else:
            root = os.path.join(os.getcwd(), root)
            self.zipfiles = glob.glob(os.path.join(root, "*.zip"))

        if len(self.zipfiles) == 0:
            print(
                "No download files found. Pass the download directory to this function or use the download() method."
            )
            return

        self.root = (
            os.path.join(os.getcwd(), self.rootname)
            if not root
            else os.path.join(os.getcwd(), root)
        )

        self.stackedDir = os.path.join(os.getcwd(), root, "stackedFiles")

        if os.path.exists(self.stackedDir):
            shutil.rmtree(self.stackedDir)
        os.makedirs(self.stackedDir)

        files = []
        self.zipfiles = sorted(self.zipfiles)

        for fpath in self.zipfiles:
            with zipfile.ZipFile(fpath, "r") as f:
                f.extractall(self.root)
                files.append(f.namelist())

        # siteDateRE = re.compile("\.[a-z]{3}_(.*)\.[0-9]{4}-[0-9]{2}\." + self.data["package"] + "(.*)\.csv")
        # siteAllRE = re.compile("\.[a-z]{3}_([a-z]*)\."+self.data["package"]+"(.*)\.csv")
        # expanded packages sometimes contain basic files.
        siteDateRE = re.compile(
            "\.[a-z]{3}_(.*)\.[0-9]{4}-[0-9]{2}\." + "[a-z]*" + "(.*)\.csv"
        )

        siteAllRE = re.compile("\.[a-z]{3}_([a-zA-Z]*)\.[a-z]*\.(.*)\.csv")

        self.siteDateFiles = [[i for i in j if siteDateRE.search(i)] for j in files]
        self.siteAllFiles = [[i for i in j if siteAllRE.search(i)] for j in files]

        self.stackedFiles = {}
        self.stack_site_date()
        self.stack_site_all()

        if clean:
            # inherited
            self.cleandir(self.root)

    def stack_site_date(self):
        # TODO site date is not always common between sites.
        flat = set([self.extractName(i) for i in list(chain.from_iterable(self.siteDateFiles))])
        for name in flat:
            filename = os.path.join(self.stackedDir, name + "_stacked.csv")
            out = neon.CSVwriter(filename)
            for other in range(len(self.siteDateFiles)):
                for i in self.siteDateFiles[other]:
                    if name in i:
                        out.append(os.path.join(self.root,i))
                        break

            out.close()
            self.stackedFiles[name] = filename

    def instances(self, name, files):
        # requires files to be presorted.
        inst = {i: None for i in self.data["site"]}
        for i in files:
            for j in i:
                if name in j:
                    inst[self.extractSite(j)] = j
                    continue
        return inst

    def stack_site_all(self):
        if len(self.siteAllFiles) == 0:
            return
        for i in self.siteAllFiles[0]:
            name = self.extractName(i)
            toStack = self.instances(name, self.siteAllFiles)
            filename = os.path.join(self.stackedDir, name + "_stacked.csv")
            outf = neon.CSVwriter(filename)
            for j in toStack:
                outf.append(os.path.join(self.root, toStack[j]))
            outf.close()
            self.stackedFiles[name] = filename

    def to_pandas(self):
        """Converts a stacked dataset into a dictionary of pandas DataFrames"""
        if len(self.stackedFiles) == 0:
            print("No files stacked")
            return
        import pandas as pd

        dfs = {}
        for i in self.stackedFiles:
            dfs[i] = pd.read_csv(self.stackedFiles[i])
        return dfs


